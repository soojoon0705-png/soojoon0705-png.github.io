@echo off
setlocal
chcp 65001 >nul
set "BLOBHUD_CHECK_ROOT=%~dp0"
set "BLOBHUD_CHECK_LOG=%~dp0Check_Result.txt"
echo BlobHUD Windows verification > "%BLOBHUD_CHECK_LOG%"
"%BLOBHUD_CHECK_ROOT%Verification\ofx_host_test.exe" "%BLOBHUD_CHECK_ROOT%Verification\BlobHUD.ofx.bundle\Contents\Win64\BlobHUD.ofx" >> "%BLOBHUD_CHECK_LOG%" 2>&1
if errorlevel 1 goto failed
"%BLOBHUD_CHECK_ROOT%Verification\windows_installer_test.exe" "%BLOBHUD_CHECK_ROOT%Verification\BlobHUD.ofx.bundle" >> "%BLOBHUD_CHECK_LOG%" 2>&1
if errorlevel 1 goto failed
echo PASS - Native checks completed. Resolve and installer UI still require testing. >> "%BLOBHUD_CHECK_LOG%"
type "%BLOBHUD_CHECK_LOG%"
echo.
echo Checks passed. You can close this window and run the Setup file.
pause
exit /b 0
:failed
echo FAIL - Stop before installation and report Check_Result.txt. >> "%BLOBHUD_CHECK_LOG%"
type "%BLOBHUD_CHECK_LOG%"
pause
exit /b 1
