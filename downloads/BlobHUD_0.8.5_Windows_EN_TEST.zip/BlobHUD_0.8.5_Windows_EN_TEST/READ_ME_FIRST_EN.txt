BlobHUD 0.8.5 / Windows x64 English TEST

1. Extract the entire ZIP.
2. Run Run_Checks.cmd and check Check_Result.txt for PASS.
   No developer tools or admin privileges are needed; system installation is not changed.
3. Save your project and quit Resolve completely.
4. Run BlobHUD_0.8.5_Setup_EN_x64_TEST.exe to install.
5. Search for BlobHUD in Resolve and check a new clip and existing projects.

Remove: quit Resolve > Windows Settings > Apps > Installed apps > BlobHUD > Uninstall.
Setup installs the removal tool, so no separate uninstaller download is needed.
English and Korean replace each other and share parameter IDs and analysis format.

For Intel/AMD x64 Windows 10 or later; also check your Resolve version's requirements.
Not for Windows ARM, 32-bit Windows or macOS.

This unsigned test build is pending real Windows Resolve, setup UI, UAC and removal
validation. Windows may display security warnings. If checks fail, stop before
installation and report Check_Result.txt. See Quick_Start_EN.html for usage.
