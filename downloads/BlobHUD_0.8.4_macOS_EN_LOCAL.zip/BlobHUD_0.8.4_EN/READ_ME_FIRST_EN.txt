BlobHUD 0.8.4 - English / macOS Apple Silicon

This ZIP contains finished install and uninstall packages.
No Terminal command or developer tools are required to install them.

Install or update
1. Save your project and quit DaVinci Resolve completely.
2. Double-click BlobHUD_0.8.4_Install_EN_arm64_LOCAL.pkg.
3. Follow macOS Installer and complete administrator authorization.
4. Restart Resolve and search for BlobHUD in Open FX.
   For a new clip, use 01 - Quick Start > Apply Recommended Settings.
   For existing projects, check the saved settings and analysis first.

Uninstall
Quit Resolve, then run BlobHUD_0.8.4_Uninstall_EN_arm64_LOCAL.pkg.
Do not run the Uninstall package when you want to install BlobHUD.
It moves the currently installed copy, in either language, to a backup folder.

Switch languages
Only one language is installed at a time. Installing the other language backs up
and replaces the current copy. You do not need to uninstall first.
Plug-in identity, parameter IDs and saved-analysis format are shared.

Platform
For DaVinci Resolve on an Apple Silicon Mac, targeting macOS 12 or later.
No Windows or Intel Mac installer is included.
Native macOS navigation buttons and authorization dialogs follow the OS language.

Distribution status
These are LOCAL test packages without Developer ID distribution signing or Apple
notarization. Other Macs may display security warnings or block installation.
Use signed and notarized packages before public distribution.
Putting these packages in a ZIP does not change their signing/notarization status.

Open Quick_Start_EN.html for detailed usage instructions.
Plug-in: /Library/OFX/Plugins/BlobHUD.ofx.bundle
Backups: /Library/Application Support/BlobHUD/Backups
