BlobHUD 0.8.5 / Windows x64 한국어 TEST

1. ZIP 전체를 압축 해제하세요.
2. Run_Checks.cmd를 실행하고 Check_Result.txt의 PASS를 확인하세요.
   개발 도구·관리자 권한은 필요 없고, 실제 시스템 설치를 변경하지 않습니다.
3. 프로젝트를 저장하고 Resolve를 완전히 종료하세요.
4. BlobHUD_0.8.5_Setup_KO_x64_TEST.exe를 실행해 설치하세요.
5. Resolve에서 BlobHUD를 검색해 새 클립과 기존 프로젝트를 확인하세요.

제거: Resolve 종료 → Windows 설정 → 앱 → 설치된 앱 → BlobHUD → 제거.
설치 도구는 제거 프로그램도 함께 설치하므로 별도 제거 파일을 받을 필요가 없습니다.
한국어·영어는 교체 설치하며 기존 설정 ID·저장 분석 형식은 같습니다.

대상은 Intel·AMD x64 Windows 10 이상입니다. Resolve 자체의 요구 사양도 확인하세요.
Windows ARM·32비트와 macOS용이 아닙니다.

이 파일은 실제 Windows Resolve·설치 UI·UAC·제거 동작을 확인하기 전 테스트 빌드입니다.
코드 서명이 없어 Windows 보안 경고가 나올 수 있습니다.
검사 실패 시 설치하지 말고 Check_Result.txt를 전달해 주세요.
자세한 사용법은 Quick_Start_KO.html을 여세요.
