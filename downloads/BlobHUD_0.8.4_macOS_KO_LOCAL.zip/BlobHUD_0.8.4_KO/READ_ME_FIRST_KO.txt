BlobHUD 0.8.4 - 한국어 / macOS Apple Silicon

이 ZIP에는 완성된 설치·제거 패키지가 들어 있습니다.
터미널 명령이나 개발 도구 없이 설치할 수 있습니다.

설치·업데이트
1. 작업 중인 프로젝트를 저장하고 DaVinci Resolve를 완전히 종료하세요.
2. BlobHUD_0.8.4_Install_KO_arm64_LOCAL.pkg를 더블클릭하세요.
3. macOS 설치 안내에 따라 관리자 인증을 완료하세요.
4. Resolve를 다시 실행하고 Open FX에서 BlobHUD를 검색하세요.
   새 클립에서는 [01 · 빠른 시작 → 추천 설정 적용]으로 시작하세요.
   기존 프로젝트에서는 저장된 설정과 분석 결과를 먼저 확인하세요.

제거
Resolve를 종료하고 BlobHUD_0.8.4_Uninstall_KO_arm64_LOCAL.pkg를 실행하세요.
설치할 때 제거용 파일을 실행할 필요는 없습니다.
제거는 현재 설치된 BlobHUD를 언어에 관계없이 백업 폴더로 옮깁니다.

한국어·영어 전환
두 버전은 한 번에 하나만 설치합니다. 다른 언어의 설치용 패키지를 실행하면
기존 버전을 백업한 뒤 교체합니다. 먼저 제거할 필요는 없습니다.
플러그인 식별자·설정 ID·분석 형식은 두 언어가 공유합니다.

지원 환경
Apple Silicon 맥 / macOS 12 이상 대상 / DaVinci Resolve용 OpenFX.
Windows와 Intel Mac용 설치 파일은 포함하지 않습니다.
macOS 기본 버튼과 관리자 인증 창은 운영체제 언어를 따릅니다.

배포 상태
이 파일은 LOCAL 테스트용입니다. Developer ID 배포 서명·Apple 공증이 없어
다른 맥에서 보안 경고나 차단이 발생할 수 있습니다.
공개 배포 전에는 서명·공증한 패키지로 교체하세요.
이 ZIP으로 다시 압축해도 패키지의 서명·공증 상태는 바뀌지 않습니다.

자세한 사용법은 Quick_Start_KO.html을 여세요.
설치 경로: /Library/OFX/Plugins/BlobHUD.ofx.bundle
백업 경로: /Library/Application Support/BlobHUD/Backups
